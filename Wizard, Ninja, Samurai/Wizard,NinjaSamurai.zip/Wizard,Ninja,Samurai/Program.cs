﻿using System;

namespace Wizard_Ninja_Samurai
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Wizard wizard1 = new Wizard("Merlin");
            Ninja ninja1 = new Ninja("Shinobi");
            Samurai samurai1 = new Samurai("Akira");
        }
    }
}